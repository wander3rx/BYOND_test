/*
	These are simple defaults for your project.
 */

world
	fps = 25		// 30 frames per second
	icon_size = 32	// 32x32 icon size by default

	view = 16		// show up to 6 tiles outward from center (13x13 view)


// Make objects move 8 pixels per tick when walking

//mob
//	step_size = 8

//obj
//	step_size = 8

mob
	var
		Aburame=""
		Akimichi=""
		rank=""
		Yen=0
		kills=0
		deaths=0
		nivel=0
		health=100
		chakra=100
		tai=10
		nin=10
		gen=10
		selos=1
		em=0
		dm=0
		cm=0
		bm=0
		am=0
		sm=0
		bugs=0
		calorias=0
		hair
		Ohair
		rhair
		ghair
		bhair
		base_hair
		Hair_Base
		HairColor
mob
	Stat()
		statpanel("Estado")
		stat(usr)
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		stat("           Informação básica")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		stat("Name: [src.name]")
		stat("Clan: [clan]")
		stat("Patente: [rank]")
		stat("Vila: [vila]")
		stat("Yen: $[Yen]")
		stat("Assassinatos: [kills]")
		stat("Mortes: [deaths]")
		stat("GPS: [x],[y],[z]")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		stat("           Atributos")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		stat("Nível: [nivel]")
		stat("Pontos de Vida: [health]")
		stat("Chakra: [chakra]")
		stat("Taijutsu: [tai]")
		stat("Ninjutsu: [nin]")
		stat("Genjutsu: [gen]")
		stat("Selos: [selos]% precisão")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		stat("Missão concluída")
		stat("E: [em]")
		stat("D: [dm]")
		stat("C: [cm]")
		stat("B: [bm]")
		stat("A: [am]")
		stat("S: [sm]")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		if(src.Aburame)
			stat("Konchuu: [bugs]")
		if(src.Akimichi)
			stat("Calorias: [calorias]")
		stat("--- --- --- --- --- --- --- --- --- --- --- --- ---")
		statpanel("Inventário")
		stat("",contents)
		..()