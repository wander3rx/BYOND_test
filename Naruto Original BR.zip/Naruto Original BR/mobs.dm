mob
    var
        clan = ""
        vila = ""


mob/player
    icon = 'player.dmi'


mob/login/proc/CreateCharacter()

    var/charname = input(src,"Escolha o nome do personagem") as text|null
    if(!charname)
        charname = "SemNome"

    var/clan = input(src,"Escolha seu cl�") in list(
        "Senju",
        "Uchiha",
        "Hyuga",
        "Akimichi",
        "Aburame"
    )

    var/vila = input(src,"Escolha sua vila") in list(
        "Folha",
        "Areia",
        "Pedra",
        "Nuvem",
        "N�voa"
    )

    var/mob/player/P = new()

    P.name = charname
    P.clan = clan
    P.vila = vila

    var/turf/T

    switch(P.vila)
        if("Folha") T = locate(10,10,1)
        if("Areia") T = locate(20,20,1)
        if("Pedra") T = locate(30,30,1)
        if("Nuvem") T = locate(40,40,1)
        if("N�voa") T = locate(50,50,1)

    if(T)
        P.loc = T
    else
        P.loc = locate(1,1,1)

    P.Save()

    client.mob = P
    del(src)


// =========================
// LOAD
// =========================
mob/login/proc/LoadCharacter()

    var/savefile/F = new("saves/[ckey].sav")

    var/mob/player/P = new()

    F["name"] >> P.name
    F["clan"] >> P.clan
    F["vila"] >> P.vila
    F["x"] >> P.x
    F["y"] >> P.y
    F["z"] >> P.z

    var/turf/T = locate(P.x, P.y, P.z)

    if(T)
        P.loc = T
    else
        P.loc = locate(1,1,1)

    client.mob = P
    del(src)


// =========================
// SAVE
// =========================
mob/player/proc/Save()

    var/savefile/F = new("saves/[ckey].sav")

    F["name"] << name
    F["clan"] << clan
    F["vila"] << vila
    F["x"] << x
    F["y"] << y
    F["z"] << z


// =========================
// AUTO SAVE
// =========================
mob/player
    Logout()
        Save()
        ..()