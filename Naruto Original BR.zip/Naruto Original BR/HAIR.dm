obj/Hairs
	Bald/Click() Apply_Hair(usr,src)
	Hair1
		New()
			icon='narutoH.dmi'
		Click() Apply_Hair(usr,src)
	Hair2
		New()
			icon='gaaraH.dmi'
		Click() Apply_Hair(usr,src)
	Hair3
		New()
			icon='kakashiH.dmi'
		Click() Apply_Hair(usr,src)
	Hair4
		New()
			icon='sakuraH.dmi'
		Click() Apply_Hair(usr,src)
	Hair5
		New()
			icon='inoH.dmi'
		Click() Apply_Hair(usr,src)


proc/Apply_Hair(mob/P,obj/Hairs/O,force_color)
	//var/Had_Tail
	//if(P.Tail) Had_Tail=1
	//P.Tail_Remove()
	P.overlays-=P.hair
	P.base_hair=null
	P.hair=O.icon
	P.Hair_Base=P.hair
	if(O.icon)
		if(force_color) P.HairColor=force_color
		else if((P.icon))
			P.HairColor=input(P,"Escolha a cor de cabelo. O padrão é preto.") as color|null
		if(P.HairColor) P.hair+=P.HairColor
		P.base_hair=P.hair
		P.overlays+=P.hair