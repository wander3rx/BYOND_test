turf
	grass
		icon = 'Landscapes.dmi'
		icon_state = "grass"
	sand
		icon = 'Landscapes.dmi'
		icon_state = "sand"
	roof1
		icon = 'turf.dmi'
		icon_state = "1"
		density=1
		opacity=1
	roof2
		icon = 'turf.dmi'
		icon_state = "2"
		density=1
		opacity=1
	roof3
		icon = 'turf.dmi'
		icon_state = "3"
		density=1
		opacity=1
	roof4
		icon = 'turf.dmi'
		icon_state = "4"
		density=1
		opacity=1